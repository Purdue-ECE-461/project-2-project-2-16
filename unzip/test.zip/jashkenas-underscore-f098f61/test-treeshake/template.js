export { template } from '../modules/index-all.js';
